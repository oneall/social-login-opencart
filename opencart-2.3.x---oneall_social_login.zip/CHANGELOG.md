# Change Log

All notable changes to this project will be documented in this file. This project adheres to [Semantic Versioning](http://semver.org/).


## [Unreleased]

## [3.6.0] - 2020-11-18
### Added
- Apple added as new provider

## [3.5.1] - 2020-07-01
### Fix
- Plugin shown twice

## [3.5.0] - 2020-04-22
### Fix
- Patreon added as new provider
- Xing added as new provider

## [3.4.1] - 2019-05-24
### Fix
- Plugin can be loaded by including a tpl file catalog/view/theme/default/template/extension/module/oneall_buttons.tpl

## [3.4.0] - 2019-04-19
### Added
- Mixer added as new provider

## [3.3.0] - 2017-10-17
### Added
- Tumblr added as new provider