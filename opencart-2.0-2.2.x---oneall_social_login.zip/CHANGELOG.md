# Change Log

All notable changes to this project will be documented in this file. This project adheres to [Semantic Versioning](http://semver.org/).


## [Unreleased]


## [2.4.0] - 2019-05-08
### Added
- Mixer added as new provider

## [2.3.0] - 2017-10-17
### Added
- Tumblr added as new provider